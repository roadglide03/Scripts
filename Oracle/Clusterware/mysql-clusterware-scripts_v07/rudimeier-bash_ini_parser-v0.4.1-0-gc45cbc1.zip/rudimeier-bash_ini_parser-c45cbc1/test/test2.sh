
# Test 2
#
# Invalid line

. ../read_ini.sh
read_ini test2.ini

